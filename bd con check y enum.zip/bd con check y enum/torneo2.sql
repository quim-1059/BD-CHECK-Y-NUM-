--vamos a eliminar el esquema base o por defecto
DROP SCHEMA Public;


--creamos el esquema para nuestra tabla
CREATE SCHEMA IF NOT EXISTS torneo2;

--creamos el  tipo ENUM para nuestras jornadas
CREATE TYPE torneo2.jornada AS ENUM(
      'mañana',
	  'tarde',
	  'noche'

);

--creamos la tabla para la entidad independiente ficha
CREATE TABLE IF NOT EXISTS torneo2.ficha(
id_ficha INT UNIQUE NOT NULL Primary key,
codigo VARCHAR(50)NOT NULL,
programa VARCHAR(50)NOT NULL,
jornada torneo2.jornada NOT NULL
);

--creamos la segunda tabla para la entidad independiente cancha
CREATE TABLE IF NOT EXISTS torneo.cancha(
id_cancha INT UNIQUE NOT NULL Primary key,
nombre VARCHAR(50)NOT NULL,
ubicacion VARCHAR(50)NOT NULL,
capacidad INT NOT NULL CONSTRAINT chk_capacidad CHECK (capacidad >0)
);

--creamos la tercera tabla para la entidad independiente arbitro
CREATE TABLE IF NOT EXISTS torneo2.arbitro(
id_arbitro INT UNIQUE NOT NULL Primary key, 
documento VARCHAR(50)NOT NULL,
nombre VARCHAR(50)NOT NULL,
celular VARCHAR(50)NOT NULL
);

--creamos la cuarta tabla para la entidad independiente equipo
CREATE TABLE IF NOT EXISTS torneo.equipo(
id_equipo INT UNIQUE NOT NULL Primary key,
nombre_equipo VARCHAR(50)NOT NULL,
color_camiseta VARCHAR(50)NOT NULL,
id_equipo_local INT UNIQUE NOT NULL,
id_equipo_visitante INT UNIQUE NOT NULL
);


--creamos la primer tabla para la entidad dependiente jugador
CREATE TABLE IF NOT EXISTS torneo2.jugador(
id_jugador INT UNIQUE NOT NULL Primary key,
documento VARCHAR(50)NOT NULL,
nombre VARCHAR(50)NOT NULL,
fecha_nacimiento DATE NOT NULL,
numero_camiseta INT NOT NULL CONSTRAINT chk_numero_camiseta CHECK (numero_camiseta >0),
id_equipo INT NOT NULL,

CONSTRAINT fk_equipo FOREIGN KEY(id_equipo)REFERENCES torneo2.equipo(id_equipo)
);

--vamos a crear el tipo ENUM en fases
CREATE TYPE torneo2.fase AS ENUM (
    'grupos',
    'cuartos',
    'semifinal',
    'final'
);

--creamos la segunda tabla para la entidad dependiente partidos
CREATE TABLE IF NOT EXISTS torneo2.partido(
id_partido INT UNIQUE NOT NULL Primary key,
fecha DATE NOT NULL,
hora TIME NOT NULL,
fase torneo2.fase NOT NULL,
id_cancha INT NOT NULL,
id_equipo_local INT NOT NULL,
id_equipo_visitante INT NOT NULL,

CONSTRAINT fk_cancha FOREIGN KEY(id_cancha)REFERENCES torneo2.cancha(id_cancha),
CONSTRAINT fk_equipo_local FOREIGN KEY(id_equipo_local)REFERENCES torneo2.equipo(id_equipo_local),
CONSTRAINT fk_equipo_visitante FOREIGN KEY(id_equipo_visitante)REFERENCES torneo2.equipo(id_equipo_visitante),
CONSTRAINT chk_equipo_local_visitante CHECK (id_equipo_local <> id_equipo_visitante)
);

CREATE TYPE torneo2.rol_arbitro AS ENUM(
          'central',
		  'asistente',
		  'anotador'
);

--creamos la tercera tabla para la entidad dependiente arbitraje
CREATE TABLE IF NOT EXISTS torneo2.arbitraje(
id_arbitraje INT UNIQUE NOT NULL Primary key,
documento_arbitro VARCHAR(50),
id_partido INT NOT NULL,
rol_arbitro torneo2.rol_arbitro NOT NULL,
CONSTRAINT fk_partido FOREIGN KEY(id_partido)REFERENCES torneo2.partido(id_partido)
);

--creamos la cuarta tabla para la entidad dependiente participacion
CREATE TABLE IF NOT EXISTS torneo2.participacion(
id_participacion INT UNIQUE NOT NULL Primary key,
id_partido INT NOT NULL,
id_jugador INT NOT NULL,
goles INT NOT NULL CONSTRAINT chk_goles CHECK(goles >= 0),
tarjetas_amarillas INT NOT NULL CONSTRAINT chk_tarjetas_amarillas CHECK(tarjetas_amarillas>= 0),
tarjeta_roja INT NOT NULL CONSTRAINT chk_tarjeta_roja CHECK(tarjeta_roja >= 0),
minutos_jugadores INT NOT NULL CONSTRAINT chk_minutos_jugadores CHECK(minutos_jugadores >=0),

CONSTRAINT fk_partido FOREIGN KEY(id_partido)REFERENCES torneo2.partido(id_partido),
CONSTRAINT fk_jugador FOREIGN KEY(id_jugador)REFERENCES torneo2.jugador(id_jugador)
);