
--vamos a eliminar el esquema base o por defecto
DROP SCHEMA Public;


--creamos el esquema para nuestra tabla
CREATE SCHEMA IF NOT EXISTS restaurante2;


--creamos la tabla para la entidad independiente cliente
CREATE TABLE IF NOT EXISTS restaurante2.cliente(
id_cliente INT UNIQUE NOT NULL primary key,
cedula VARCHAR(50)NOT NULL,
nombre VARCHAR(50)NOT NULL,
celular VARCHAR(50)NOT NULL,
direccion VARCHAR(100)NOT NULL,
barrio VARCHAR(100)NOT NULL
);


--creamos el tipo ENUM para nuestra categorias
CREATE TYPE restaurante2.nombre_categoria AS ENUM(
    'hamburguesas',
    'perros calientes',
    'salchipapas',
    'bebidas',
    'picadas'

);


--creamos la segunda tabla para la entidad independiente categoria
CREATE TABLE IF NOT EXISTS restaurante2.categoria(
id_categoria INT UNIQUE NOT NULL Primary key,
nombre_categoria restaurante2.nombre_categoria NOT NULL
);


--creamos la tercera tabla para la entidad independiente moto
CREATE TABLE IF NOT EXISTS restaurante2.moto(
id_moto INT UNIQUE NOT NULL Primary key,
placa_moto VARCHAR(50)UNIQUE NOT NULL,
modelo_moto VARCHAR(50)NOT NULL,
vencimiento_soat DATE NOT NULL
); 

--creamos la tabla dependiente platos
CREATE TABLE IF NOT EXISTS restaurante2.plato(
id_plato INT UNIQUE NOT NULL Primary key,
nombre_plato VARCHAR(50)NOT NULL,
precio_actual DECIMAL(11,0)NOT NULL CONSTRAINT chk_precio_actual CHECK (precio_actual >0),
id_categoria INT NOT NULL,

CONSTRAINT fk_categoria FOREIGN KEY(id_categoria)REFERENCES restaurante2.categoria(id_categoria)
);

--creamos la segunda tabla dependiente domiciliario
CREATE TABLE IF NOT EXISTS restaurante2.domiciliario(
id_domiciliario INT UNIQUE NOT NULL Primary key,
nombre_domiciliario VARCHAR(50),
id_moto INT NOT NULL,

CONSTRAINT fk_moto FOREIGN KEY(id_moto)REFERENCES restaurante2.moto(id_moto)
);

-- creamos el tipo ENUM para estado pedido
CREATE TYPE restaurante2.estado_pedido AS ENUM (
    'pendiente',
    'en preparacion',
    'enviado',
    'entregado',
    'cancelado'
);

--creamos la tercera tabla dependiente pedido
CREATE TABLE IF NOT EXISTS restaurante2.pedido(
id_pedido INT UNIQUE NOT NULL Primary key,
fecha_pedido DATE NOT NULL,
estado_pedido restaurante2.estado_pedido NOT NULL ,
id_cliente INT NOT NULL,
id_domiciliario INT NOT NULL,

CONSTRAINT fk_cliente FOREIGN KEY(id_cliente)REFERENCES restaurante2.cliente(id_cliente),
CONSTRAINT fk_domiciliario FOREIGN KEY(id_domiciliario)REFERENCES restaurante2.domiciliario(id_domiciliario) 
);

--creamos la cuarta tabla dependiente detalle_pedido
CREATE TABLE IF NOT EXISTS restaurante2.detalle_pedido(
id_detalle_pedido INT UNIQUE NOT NULL Primary key,
cantidad INT NOT NULL,
precio_unitario DECIMAL(10,1)CONSTRAINT chk_precio_unitario CHECK (precio_unitario >0),
id_pedido INT UNIQUE NOT NULL,
id_plato INT UNIQUE NOT NULL,

CONSTRAINT fk_pedido FOREIGN KEY(id_pedido)REFERENCES restaurante2.pedido(id_pedido),
CONSTRAINT fk_plato FOREIGN KEY(id_plato)REFERENCES restaurante2.plato(id_plato)
);