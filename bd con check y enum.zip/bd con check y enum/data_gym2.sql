--ingresamos datos a la tabla planes
INSERT INTO 
gym2.planes(id_plan,nombre_plan,duracion_plan ,precio_plan)
VALUES(1,'trimestral','1','50.000'),
      (2,'anual','2','100.000');

--ingresamos datos a la tabla entrenadores
INSERT INTO 
gym2.entrenadores(id_entrenador,nombre_entrenador,documento_entrenador,especialidad_entrenador)
VALUES(3,'jairo','1067234567','yoga'),
      (4,'mauricio','1023456787','pilates');

	  DELETE FROM gym2.entrenadores
WHERE id_entrenador IN (3, 4);



-- ingresamos datos a la tabla socios 
INSERT INTO 
gym2.socios(id_socio,nombre_socio,documento_socio,telefono,fecha_ingreso,id_plan)
VALUES(5,'mateo','1034567865','3213456789','2025/12/9','1'),
      (6,'maria','1067895674','3234567890','2020/11/11','2');


--ingresamos datos a la tabla clases
INSERT INTO 
gym2.clases(id_clase,nombre_clase,id_entrenador)
VALUES(7,'yoga','3'),
      (8,'zumba','4');


--ingresamos datos a la tabla tarjeta
INSERT INTO 
gym2.tarjeta(id_tarjeta,codigo,fecha_vencimiento,estado_tarjeta,id_socio)
VALUES (9,'2122','2025/12/23','activa','5'),
       (10,'2324','2023/07/12','vencida','6');

--ingresamos datos a la tabla asistencia
INSERT INTO
gym2.asistencias(id_asistencia,id_socio,id_clase,fecha_asistencia)
VALUES (11,'5','7','2025/10/15'),
       (12,'6','8','2024/11/12');