--vamos a eliminar el esquema base o por defecto
DROP SCHEMA Public;

--creamos el esquema para nuestra 
CREATE SCHEMA IF NOT EXISTS gym2;

--creamos la tabla para la entidad independiente planes
CREATE TABLE IF NOT EXISTS gym2.planes(
id_plan INT UNIQUE NOT NULL primary key,
nombre_plan VARCHAR(50)NOT NULL,
duracion_plan INT NOT NULL CONSTRAINT chk_duracion_plan CHECK (duracion_plan >= 0),
precio_plan DECIMAL(11,0)NOT NULL CONSTRAINT chk_precio_plan CHECK (precio_plan >0)
);

--creamos el tipo  ENUM para las clases
CREATE TYPE gym2.especialidad AS ENUM (
    'musculacion',
    'yoga',
    'pilates',
    'spinning',
    'funcional'
);

--creamos la segunda tabla independiente entrenadores
CREATE TABLE IF NOT EXISTS gym2.entrenadores(
id_entrenador INT UNIQUE NOT NULL primary key,
nombre_entrenador VARCHAR(50)NOT NULL,
documento_entrenador VARCHAR(50)NOT NULL,
especialidad_entrenador gym2.especialidad NOT NULL
);




--creamos la tabla para la segunda entidad dependiente socios
CREATE TABLE IF NOT EXISTS gym2.socios(
id_socio INT UNIQUE NOT NULL primary key,
nombre_socio VARCHAR(50)NOT NULL,
documento_socio VARCHAR(50)NOT NULL,
telefono VARCHAR(50)NOT NULL,
fecha_ingreso DATE NOT NULL,
id_plan INT  NOT NULL,


CONSTRAINT fk_planes FOREIGN KEY(id_plan) REFERENCES gym2.planes(id_plan)
);


--creamos el tipo ENUM para las clases
CREATE TYPE gym2.tipo_clase AS ENUM (
    'yoga',
    'zumba',
    'spinning',
    'pilates',
    'aerobicos'
);

--creamos la tabla para la tercera entidad dependiente clases
CREATE TABLE IF NOT EXISTS gym2.clases(
id_clase INT UNIQUE NOT NULL primary key,
nombre_clase gym2.tipo_clase NOT NULL,
id_entrenador INT NOT NULL,
CONSTRAINT fk_entrenadores FOREIGN KEY(id_entrenador) REFERENCES gym2.entrenadores
);

--creamos el tipo ENUM para el estado de las tarjetas
CREATE TYPE gym2.estado_tarjeta AS ENUM (
    'activa',
    'vencida',
    'bloqueada'
);

--creamos la tabla para la entidad dependiente tarjeta
CREATE TABLE IF NOT EXISTS gym2.tarjeta(
id_tarjeta INT UNIQUE NOT NULL primary key,
codigo VARCHAR(50)NOT NULL,
fecha_vencimiento DATE NOT NULL,
estado_tarjeta gym2.estado_tarjeta NOT NULL,
id_socio INT NOT NULL,
CONSTRAINT fk_socios FOREIGN KEY(id_socio) REFERENCES gym2.socios(id_socio)
);




--creamos la tabla tercera entidad dependiente asistencias
CREATE TABLE IF NOT EXISTS Gimnas.asistencias(
id_asistencia INT UNIQUE NOT NULL primary key,
id_socio INT NOT NULL,
id_clase INT NOT NULL,
fecha_asistencia DATE NOT NULL,
CONSTRAINT fk_socios FOREIGN KEY(id_socio) REFERENCES Gimnasio.socios(id_socio),
CONSTRAINT fk_clase FOREIGN KEY(id_clase) REFERENCES Gimnasio.clases(id_clase)
);